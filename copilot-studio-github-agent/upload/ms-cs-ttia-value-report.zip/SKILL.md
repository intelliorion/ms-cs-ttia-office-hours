---
name: ms-cs-ttia-value-report
description: >-
  Morgan Stanley Corporate Services CSIC value report, run by TTIA. Use when a
  Corporate Services initiative is already in service (live, launched,
  delivered, rolled out, or a pilot with results)
  and someone needs to report the value, benefit, outcome or ROI it delivered;
  prepare a CSIC value update or leadership summary; check whether a claimed
  benefit can be evidenced against its intake baseline; or answer "how much
  productivity, risk reduction, cost avoidance or reach did we get". Not for
  initiatives still at idea, proposal or build stage - use
  ms-cs-ttia-office-hours for those.
---

# MS Corporate Services — TTIA value report

**POST-SUBMISSION.** Companion to the **ms-cs-ttia-office-hours** skill, which
covers everything up to the intake form. Use this only when an initiative is
**in service** and there is an outcome to report. Intake predicted a benefit
and named who would capture the baseline; this is where that promise is tested.

If the initiative turns out not to be in service yet, stop and switch to
**ms-cs-ttia-office-hours**: a value report on something that has not happened
is a forecast dressed as a result.

## How to run this in chat (Copilot Studio)

- **One question per message** while gathering evidence. Short turns.
- **Evidence comes from files the user uploads or knowledge sources you
  actually retrieve in this conversation.** Ask them to upload the intake
  record, status reports and system exports. Agent memory is not evidence —
  if you recall a figure from an earlier conversation, it needs a source
  opened in this one before it can be cited.
- **Never ask for raw personal or client data.** Aggregates (counts, medians,
  totals) are enough for every claim this report makes. If an upload contains
  individual-level personal data, say so, do not quote it, and ask for the
  aggregate instead.

## Step 1 — find the intake record, and hold it to account

Ask for the intake record (the CSIC intake sheet or `CSIC-intake-*.docx`) first.
If they have it, read it and answer three questions in the report itself:

- **Was the baseline actually captured?** The record named an owner and a date.
  Did it happen? If not, the outcome cannot be evidenced, and the report says
  so rather than working around it.
- **Is the benefit the one predicted?** Initiatives routinely deliver something
  other than the case that was approved. That is not a failure. Reporting the
  approved benefit when a different one arrived is.
- **Is the accountable person still accountable?** If they moved, name who
  holds it now, or say nobody does.

No intake record? Say so at the top. It means nobody agreed in advance what
success would look like, and everything below is being defined after the fact.

## Step 2 — read the sources and list what you read

Status reports, system exports, the portfolio record, email threads — uploaded
here or retrieved from the agent's knowledge sources. **If you did not open it
in this conversation, you may not cite it.** List every document by name.

## Step 3 — the claim table, before any prose

| id | tier | metric | before | after | unit | value driver | source |
|---|---|---|---|---|---|---|---|

| tier | when | requires |
|---|---|---|
| **measured** | a real before and after exist in a cited source | both figures, a unit, and the document they came from |
| **estimated** | inferred or asserted, not measured | the assumption stated, and a person or role who owns it |
| **qualitative** | something changed with no number | a sentence, and **no figure at all** |

**The test: could someone re-run the query and get the same number?** If yes,
measured. If no, estimated.

If a figure needs arithmetic (a median, a percentage change, a total), compute
it exactly with your code sandbox from the uploaded file, and name the file and
column in the source cell. Do not estimate arithmetic by eye.

**A rubric score is never a business result.** Effectiveness 4, efficiency 2, a
priority score that moved between assessments — prioritisation judgements about
what to build next. A grade that moved is a reassessment that used more
evidence, not a change in the world. This is the most tempting fake outcome
available; refuse it.

Show the claim table in chat and ask the user to confirm it before writing
anything else.

## Step 4 — write the report on the five cards

1. **What problem were we solving?** — prose, no figures
2. **What capability did AI unlock?** — prose, no figures
3. **What outcome improved?** — carries the claims from the table
4. **Which value driver did it advance?** — one primary
   (Effectiveness: `productivity` · `operational-adaptability` ·
   `governance-oversight` · `standardization-knowledge` ·
   `high-value-skills-ip` · `differentiation`; Efficiency:
   `labor-cost-efficiency` · `process-cost-efficiency` ·
   `overhead-cost-efficiency` · `capex-reduction`). Never sum across drivers.
5. **Who is accountable?** — named leader, value realization owner, reporting
   cadence, and whether the number is actually tracked today

**Cards 1, 2, 4 and 5 contain no figures.** A number in prose is a number
nobody can trace.

## Step 5 — the five leadership questions, including the ones you cannot answer

1. How much more productivity did we get?
2. How much risk did we reduce? — control exceptions, error rates, audit findings
3. What new capabilities do we now have?
4. How much cost did we avoid? — cost avoided, never revenue
5. How many employees and functions were enabled?

**Risk and reach are the two that get missed.** "No baseline was captured, so
processing time is not claimed" is more useful than a number nobody can defend,
and it points at the fix.

## Step 6 — the Word document

Create **`CSIC-value-report-{use-case}.docx`** with your file-creation
capability, mirroring `CSIC-case-{use-case}.docx` from intake in the past
tense, so the two can be read side by side: what was expected, and what
happened. Offer a PDF copy for circulation.

- Header on every page: `CSIC value report — {use case} — {CS function} — {date}`.
- Opening block: whether an intake record was found; the three Step 1 answers.
- Then the five cards, then the five leadership questions (answered or reported
  as unanswered), then **Sources read** — every document by name.
- Render the tier **structurally, not as a label**:
  - *measured*: a small table — `Before: {figure} {unit}` · `After: {figure}
    {unit}` · `Source: {document}`.
  - *estimated*: `Estimate: {figure} {unit}` with `Assumption: … — owned by …`
    beside it.
  - *qualitative*: one italic sentence, no table, no numeral.
- An expected benefit that did not arrive is reported as not arrived, not
  quietly replaced.
- Never use colour alone to carry meaning; it must survive black-and-white
  printing.

**If you cannot create files** in this environment, deliver the report in chat
in the exact layout in `references/value-story-chat.md` in this skill package
(section B): same sections, same tier layouts,
one message, ending with whether the initiative can evidence what it claims.

## Before it goes to anyone

- [ ] Every figure traces to a claim in the table.
- [ ] No figure in a heading or in prose.
- [ ] No qualitative claim contains a numeral.
- [ ] Every measured claim has a before, an after, a unit and a named source.
- [ ] Every estimated claim names who owns the assumption.
- [ ] No rubric score is tiered measured.
- [ ] Every cited document was actually opened in this conversation.
- [ ] Each of the five questions answered, or reported as unanswered.
- [ ] The intake record's baseline promise reported on — kept or not.

## Not repairs

- Downgrading a measured claim to qualitative because the baseline cannot be
  found. Find the number, or state the gap.
- Deleting a claim so a value driver looks better covered.
- Rewording a number to make a problem go away.
- Citing a document nobody opened.

Close by saying, in the chat message itself, whether the initiative can
evidence what it claims. If it cannot, the finding is not that the initiative
failed — it is that nobody captured the before. Name who should start now.
